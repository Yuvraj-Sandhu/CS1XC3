/**
 * @file student.h
 * @author Yuvraj Singh Sandhu (sandhy1@mcmaster.ca)
 * @brief This header file is for the student.c file
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief student type which is used to store first_name, last_name, id, grade, num_grades
 * 
 */

typedef struct _student 
{ 
  char first_name[50]; // represents the students's first name
  char last_name[50]; // represents the students's last name
  char id[11]; // represent the id of the student
  double *grades; // represent the grades of the student
  int num_grades; // represents the number of different grades of the student
} Student;

// functions defined in the student.c file
void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
