/**
 * @file course.h
 * @author yuvraj Singh Sandhu (sandhy1@mcmaster.ca)
 * @brief This header file is for the course.c file
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>

/**
 * @brief course type which is used to store the name, code, students, total_students.
 * 
 */

typedef struct _course 
{
  char name[100]; // represents the course's name
  char code[10]; // represents the code of the course
  Student *students; // represents the students enrolled in the course
  int total_students; // represents the number of total students enrolled in the course
} Course;

// functions defined in the course.c file.
void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


